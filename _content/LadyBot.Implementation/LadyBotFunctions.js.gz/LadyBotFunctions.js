﻿function beginAnimations(id) {
    document.getElementById(id).beginElement();
}
